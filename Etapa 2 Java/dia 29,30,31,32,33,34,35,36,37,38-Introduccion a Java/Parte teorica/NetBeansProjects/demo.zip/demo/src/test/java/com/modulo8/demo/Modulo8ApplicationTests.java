package com.modulo8.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Modulo8ApplicationTests {

	@Test
	void contextLoads() {
	}

}
